# mini-stock-market
A mini C++ stock market simulator
